//
//  ViewController.m
//  转十六进制颜色
//
//  Created by 小震GG on 2018/10/23.
//  Copyright © 2018年 小震GG. All rights reserved.
//

#import "ViewController.h"
#import "UIColor+Hex.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIView *view1 = [[UIView alloc]initWithFrame:CGRectMake(100, 100, 100, 100)];
    [self.view addSubview:view1];
    //颜色的alpha值为1，直接填入十六进制色值即可
    view1.backgroundColor = [UIColor colorWithHexString:@"#5457FF"];
    
    UIView *view2 = [[UIView alloc]initWithFrame:CGRectMake(100, 300, 100, 100)];
    [self.view addSubview:view2];
    //颜色的alpha可变，值为0-1范围
    view2.backgroundColor = [UIColor colorWithHexString:@"#5457FF" alpha:0.8];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
