//
//  ViewController.m
//  GCD
//
//  Created by 小震GG on 2018/9/17.
//  Copyright © 2018年 小震GG. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
//    1.串行队列＋同步任务：不会开启新的线程，任务逐步完成。
//    2.串行队列＋异步任务：开启新的线程，任务逐步完成。
//    3.并发队列＋同步任务：不会开启新的线程，任务逐步完成。
//    4.并发队列＋异步任务：开启新的线程，任务同步完成。

    //串行队列，同步任务
    dispatch_queue_t t = dispatch_queue_create("串行同步", NULL);
    //参数一：队列名称   //参数二：队列属性
    //如下:
    for (int i = 0; i < 10; i++) {
        dispatch_sync(t, ^{
            NSLog(@"串行同步：%d--%@", i, [NSThread currentThread]);
        });
    }
    
    //串行队列，异步任务
    dispatch_queue_t tt = dispatch_queue_create("串行异步", NULL);
    for (int i = 0; i < 10; i++) {
        dispatch_async(tt, ^{
            NSLog(@"串行异步：%d--%@", i, [NSThread currentThread]);
        });
    }
    
    //并发队列，同步任务
    dispatch_queue_t ttt = dispatch_queue_create("并发同步", DISPATCH_QUEUE_CONCURRENT);
    for (int i = 0; i < 10; i++) {
        dispatch_sync(ttt, ^{
            NSLog(@"并发同步：%d--%@", i, [NSThread currentThread]);

        });
    }
    
    //并发队列，异步任务
    dispatch_queue_t tttt = dispatch_queue_create("并发异步", DISPATCH_QUEUE_CONCURRENT);
    for (int i = 0; i < 10; i++) {
        dispatch_async(tttt, ^{
            NSLog(@"并发异步：%d--%@", i, [NSThread currentThread]);
        });
    }
    
    //全局任务，本质上是并列队列
    dispatch_queue_t q = dispatch_get_global_queue(0, 0);
    //参数一：0 既可以适配iOS7，也可以适配iOS8，且为默认优先级
    //参数二：0 为未来使用的一个保留，现在始终给0，预留参数
    for (int i = 0; i < 10; i++) {
        dispatch_async(q, ^{
            NSLog(@"全局并发异步：%d--%@", i, [NSThread currentThread]);
        });
    }
    
    //一次执行任务
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        //未执行这里时，onceToken是0，处于可执行状态，一旦执行之后，onceToken就变成-1，就再也不会执行了
        NSLog(@"%@", [NSThread currentThread]);
    });
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
