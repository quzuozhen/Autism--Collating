//
//  AppDelegate.h
//  GCD
//
//  Created by 小震GG on 2018/9/17.
//  Copyright © 2018年 小震GG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

